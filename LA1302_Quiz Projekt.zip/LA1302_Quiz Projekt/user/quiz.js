// Send a request to the API endpoint to retrieve the data
var questionData;
var CanswerData;
var buttonHTML;
var button;
var option1;
var option2;
var option3;

fetch(
  "https://opentdb.com/api.php?amount=10&category=9&difficulty=easy&type=multiple"
)
  .then((response) => response.json())
  .then((data) => {
    questionData = data.results[0].question;
    CanswerData = data.results[0].correct_answer;
    option1 = data.results[0].incorrect_answers[0];
    option2 = data.results[0].incorrect_answers[1];
    option3 = data.results[0].incorrect_answers[2];
  })
  .then(() => {
    postQuestion();
  });

function postQuestion() {
  document.querySelector(".question").innerHTML = questionData;

  const correct_answer = document.querySelector(".option-a");
  correct_answer.innerHTML = 1 + "       " + CanswerData;

  const option_1 = document.querySelector(".option-b");
  option_1.innerHTML = 2 + "       " + option1;

  const option_2 = document.querySelector(".option-c");
  option_2.innerHTML = 3 + "       " + option2;

  const option_3 = document.querySelector(".option-d");
  option_3.innerHTML = 4 + "       " + option3;
}

var buttons = document.querySelectorAll(".option-div");

for (var i = 0; i < buttons.length; i++) {
  buttons[i].addEventListener("click", function () {});
}
