var issue;
var loggedIn;
var msg;
const LoginBtn = document.getElementById("login-btn");

LoginBtn.addEventListener("click", (e) => {
  e.preventDefault();
  const login = "http://localhost:3000/login";
  const Username_text = document.getElementById("username").value;
  const Password_text = document.getElementById("password").value;
  fetch(login, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      username: Username_text,
      password: Password_text,
    }),
  })
    .then((response) => response.json())
    .then((data) => {
      console.log(data);
      issue = data.err;
      loggedIn = data.login;
      msg = data.msg;
    })
    .then(() => {
      if (issue == false || loggedIn == true) {
        consoleLogged();
      } else if (issue == true || loggedIn == false) {
        consoleNotLogged();
      }
    })

    .catch((err) => {
      console.log(err);
    });
});

function consoleLogged() {
  document.querySelector(".before-login").innerHTML = msg;
  window.location.href = "quiz.html";
  const button = document.getElementById("ToLinkHome");
  button.click();
}

function consoleNotLogged() {
  document.querySelector(".before-login").innerHTML = msg;
}
